function addToCart() {
  alert("Product added to cart!");
}